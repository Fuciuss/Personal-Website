<template>
    <div class="timeline">
        <div class="timeline-wrap">
            <slot />
        </div>
    </div>
</template>

<script>
export default {
  name: 'CTimeline'
}
</script>
