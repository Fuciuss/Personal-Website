module.exports = {
  runtimeCompiler: true
};